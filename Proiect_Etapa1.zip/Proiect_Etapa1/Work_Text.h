#ifndef WORK_TEXT_H
#define WORK_TEXT_H

#include"Work.h"
#include"Exceptii.h"

class Work_Text:public Work
{
	static int cnt;
public: 
	Work_Text(){};
	Work_Text(char *nume):Work(nume)
	{
	this->tip=new char[6];
	strcpy(this->tip,"Text");
	}
	void scan(char*,char *w=NULL) ;
	void strict_scan(char*, int p,char*w=NULL);
	static int &get_cnt();
};
#endif