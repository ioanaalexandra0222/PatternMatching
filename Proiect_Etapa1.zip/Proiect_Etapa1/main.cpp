#include"Scan_Manager.h" 

void main()
{
	Scan_Manager *pSM = Scan_Manager::Get_ScanManager("fisiere.txt",6); 
	pSM->add_virus("infectat");
	pSM->add_virus("zero");
	pSM->add_virus("virusi.exe");
	pSM->add_virus("virusi2.exe");
	pSM->scan(); 

	Scan_Manager::distruge();  
}