	Acestea sunt componentele ce ajuta la constituirea unui proiect in Visual Studio.
	Scopul este de a analiza toate fisierele (in acest caz fisiere text sau executabile)
indicate in fisiere.txt pentru a detecta daca acestea contin semnaturile unor "virusi".
	Fisierele vor fi scanate in moduri diferite in functie de extensie.
	Informatiile dupa scanare se vor afisa in raport.txt .