#include"Work_Text.h"

int Work_Text::cnt=0;

void Work_Text::scan(char *virusi,char *w)
{ 
	try{
	FILE *f;
	if(w==NULL)
	f=fopen(this->nume_fisier,"r");
	else f=fopen(w,"r"); 	
	if(f==NULL)
	{
		if(w==NULL)
		throw new Exceptii("Eroare la deschiderea fisierului ",this->nume_fisier);
		else throw new Exceptii("Eroare la deschiderea fisierului ",w);

	}
	bool ok=true; 
	if (f!=NULL)
	{
		while (!feof(f))
		{ 
			char aux[20];
			fscanf(f,"%s",aux); 
				if (strcmp(virusi,aux)==0)
				{
					cnt++;
				} 
		}
		ok=false;
	}
	 
	if (ok==false) 
	
	fclose(f);
 }
catch(Exceptii*e)
 {
		ofstream h("raport.txt", ios :: app);
		h<<"\n"<<e->get_denum()<<" "<<e->get_functie();
		delete e;
		h.close();
		throw 0;
 }
}


void Work_Text::strict_scan(char* virusi, int p,char *w)
{  
	try{
	FILE *f;
	if(w==0)
	f=fopen(this->nume_fisier,"r");
	else f=fopen(w,"r");
	if(f==NULL)
	{
		if(!w)
		throw new Exceptii("Eroare la deschiderea fisierului ",this->nume_fisier);
		else throw new Exceptii("Eroare la deschiderea fisierului ",w);
	}
	bool ok=true; 
	if (f!=NULL)
	{
		while (!feof(f))
		{ 
			char aux[20];
			fscanf(f,"%s",aux); 
				if (strncmp(virusi,aux,(p*strlen(aux))/100)==0)
				{
					cnt++;
				} 
		}
		ok=false;
	}
	 
	if (ok==false) 
		
	fclose(f);
	}
	catch(Exceptii*e)
{
		ofstream h("raport.txt", ios :: app);
		h<<"\n"<<e->get_denum()<<" "<<e->get_functie();
		delete e;
		h.close();
		throw 0;
}
}

int& Work_Text::get_cnt()
{
	return cnt;
}